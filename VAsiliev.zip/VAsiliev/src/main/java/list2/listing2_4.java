package list2;

class ForStatementDemo {
    public static void main(String[] arge){
        int count;
        for (count=0; count<5;count=count +1)
            System.out.println("Переменна цикла равна" +count);
        System.out.println("Цикл окончен");
    }//main(String[]) method
}//ForStatementDemo class

