package list2;


class AssignExample {
    public static void main(String[] arge ) {
        //объявляем две переменные
        int var1;
        int var2;
        //присваиваем им значения
        var1=4069;
        var2=var1 / 4;
        //выводим текущие значения перемнных
        System.out.println("var1="+var1);
        System.out.println("var2=var1/4="+var2);
    }//main()
}//AssignExample class